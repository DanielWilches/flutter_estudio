# APLICACIÓN MÓVIL 

En este repositorio se encuentra alojado una alplicación Móvil creada con FLutter que hace uso de la Api de Rick anf Morty.

## CUENTA CON

-Login

-Registro

-Inicio

-Menu lateral para ver los personajes favoritos

-Boton flotante para modificar datos.
  
-Descripción de personajes

 -Boton para compartir personaje.
